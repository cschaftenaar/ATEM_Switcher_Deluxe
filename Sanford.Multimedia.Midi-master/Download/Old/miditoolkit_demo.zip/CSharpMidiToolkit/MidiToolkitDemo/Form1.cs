using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Multimedia.Midi;
using Multimedia.Midi.UI;

namespace MidiToolkitDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private const int TrackCount = 16;

        private const int TickInterval = 24;

        private int tickCounter = 0;

        private bool updatePosition = true;

        private bool updateTempo = true;

        private TrackControl[] trackControls = new TrackControl[TrackCount];
        private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.MenuItem fileMenuItem;
        private System.Windows.Forms.MenuItem fileOpenMenuItem;
        private System.Windows.Forms.MenuItem fileSeperator1MenuItem;
        private System.Windows.Forms.MenuItem fileExitMenuItem;
        private System.Windows.Forms.MenuItem midiMenuItem;
        private System.Windows.Forms.MenuItem midiInputDeviceMenuItem;
        private System.Windows.Forms.MenuItem midiOutputDeviceMenuItem;
        private System.Windows.Forms.MenuItem midiSeperator1MenuItem;
        private System.Windows.Forms.MenuItem midiMasterEnabledMenuItem;
        private System.Windows.Forms.MenuItem midiSlaveEnabledMenuItem;
        private System.Windows.Forms.MenuItem helpMenuItem;
        private System.Windows.Forms.MenuItem helpAboutMenuItem;
        private MidiToolkitDemo.TrackControl trackControl1;
        private MidiToolkitDemo.TrackControl trackControl2;
        private MidiToolkitDemo.TrackControl trackControl3;
        private MidiToolkitDemo.TrackControl trackControl4;
        private MidiToolkitDemo.TrackControl trackControl5;
        private MidiToolkitDemo.TrackControl trackControl6;
        private MidiToolkitDemo.TrackControl trackControl7;
        private MidiToolkitDemo.TrackControl trackControl8;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button continueButton;
        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.HScrollBar positionHScrollBar;
        private System.Windows.Forms.Label positionLabel;
        private System.Windows.Forms.NumericUpDown tempoNumericUpDown;
        private System.Windows.Forms.Label tempoLabel;
        private System.Windows.Forms.GroupBox trackGroupBox;
        private System.Windows.Forms.GroupBox playbackGroupBox;
        private Multimedia.Midi.Sequencer sequencer1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private MidiToolkitDemo.TrackControl trackControl16;
        private MidiToolkitDemo.TrackControl trackControl15;
        private MidiToolkitDemo.TrackControl trackControl14;
        private MidiToolkitDemo.TrackControl trackControl13;
        private MidiToolkitDemo.TrackControl trackControl12;
        private MidiToolkitDemo.TrackControl trackControl11;
        private MidiToolkitDemo.TrackControl trackControl10;
        private MidiToolkitDemo.TrackControl trackControl9;
        private System.ComponentModel.IContainer components;

		public Form1()
		{
            try
            {
                //
                // Required for Windows Form Designer support
                //
                InitializeComponent();


                trackControls[0] = trackControl1;
                trackControls[1] = trackControl2;
                trackControls[2] = trackControl3;
                trackControls[3] = trackControl4;
                trackControls[4] = trackControl5;
                trackControls[5] = trackControl6;
                trackControls[6] = trackControl7;
                trackControls[7] = trackControl8;
                trackControls[8] = trackControl9;
                trackControls[9] = trackControl10;
                trackControls[10] = trackControl11;
                trackControls[11] = trackControl12;
                trackControls[12] = trackControl13;
                trackControls[13] = trackControl14;
                trackControls[14] = trackControl15;
                trackControls[15] = trackControl16;

                foreach(TrackControl t in trackControls)
                {
                    t.TrackMuted += new EventHandler(OnTrackMute);
                    t.TrackSoloed += new EventHandler(OnTrackSolo);
                }

                sequencer1.AttachToTickGenerator(new EventHandler(TickHandler));
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK,
                    MessageBoxIcon.Stop);

                Close();
            }
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.fileMenuItem = new System.Windows.Forms.MenuItem();
            this.fileOpenMenuItem = new System.Windows.Forms.MenuItem();
            this.fileSeperator1MenuItem = new System.Windows.Forms.MenuItem();
            this.fileExitMenuItem = new System.Windows.Forms.MenuItem();
            this.midiMenuItem = new System.Windows.Forms.MenuItem();
            this.midiInputDeviceMenuItem = new System.Windows.Forms.MenuItem();
            this.midiOutputDeviceMenuItem = new System.Windows.Forms.MenuItem();
            this.midiSeperator1MenuItem = new System.Windows.Forms.MenuItem();
            this.midiMasterEnabledMenuItem = new System.Windows.Forms.MenuItem();
            this.midiSlaveEnabledMenuItem = new System.Windows.Forms.MenuItem();
            this.helpMenuItem = new System.Windows.Forms.MenuItem();
            this.helpAboutMenuItem = new System.Windows.Forms.MenuItem();
            this.trackControl1 = new MidiToolkitDemo.TrackControl();
            this.trackControl2 = new MidiToolkitDemo.TrackControl();
            this.trackControl3 = new MidiToolkitDemo.TrackControl();
            this.trackControl4 = new MidiToolkitDemo.TrackControl();
            this.trackControl5 = new MidiToolkitDemo.TrackControl();
            this.trackControl6 = new MidiToolkitDemo.TrackControl();
            this.trackControl7 = new MidiToolkitDemo.TrackControl();
            this.trackControl8 = new MidiToolkitDemo.TrackControl();
            this.trackControl16 = new MidiToolkitDemo.TrackControl();
            this.trackControl15 = new MidiToolkitDemo.TrackControl();
            this.trackControl14 = new MidiToolkitDemo.TrackControl();
            this.trackControl13 = new MidiToolkitDemo.TrackControl();
            this.trackControl12 = new MidiToolkitDemo.TrackControl();
            this.trackControl11 = new MidiToolkitDemo.TrackControl();
            this.trackControl10 = new MidiToolkitDemo.TrackControl();
            this.trackControl9 = new MidiToolkitDemo.TrackControl();
            this.startButton = new System.Windows.Forms.Button();
            this.continueButton = new System.Windows.Forms.Button();
            this.stopButton = new System.Windows.Forms.Button();
            this.positionHScrollBar = new System.Windows.Forms.HScrollBar();
            this.positionLabel = new System.Windows.Forms.Label();
            this.tempoNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.tempoLabel = new System.Windows.Forms.Label();
            this.trackGroupBox = new System.Windows.Forms.GroupBox();
            this.playbackGroupBox = new System.Windows.Forms.GroupBox();
            this.sequencer1 = new Multimedia.Midi.Sequencer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.tempoNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                      this.fileMenuItem,
                                                                                      this.midiMenuItem,
                                                                                      this.helpMenuItem});
            // 
            // fileMenuItem
            // 
            this.fileMenuItem.Index = 0;
            this.fileMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                         this.fileOpenMenuItem,
                                                                                         this.fileSeperator1MenuItem,
                                                                                         this.fileExitMenuItem});
            this.fileMenuItem.Text = "&File";
            // 
            // fileOpenMenuItem
            // 
            this.fileOpenMenuItem.Index = 0;
            this.fileOpenMenuItem.Text = "&Open...";
            this.fileOpenMenuItem.Click += new System.EventHandler(this.fileOpenMenuItem_Click);
            // 
            // fileSeperator1MenuItem
            // 
            this.fileSeperator1MenuItem.Index = 1;
            this.fileSeperator1MenuItem.Text = "-";
            // 
            // fileExitMenuItem
            // 
            this.fileExitMenuItem.Index = 2;
            this.fileExitMenuItem.Text = "E&xit";
            this.fileExitMenuItem.Click += new System.EventHandler(this.fileExitMenuItem_Click);
            // 
            // midiMenuItem
            // 
            this.midiMenuItem.Index = 1;
            this.midiMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                         this.midiInputDeviceMenuItem,
                                                                                         this.midiOutputDeviceMenuItem,
                                                                                         this.midiSeperator1MenuItem,
                                                                                         this.midiMasterEnabledMenuItem,
                                                                                         this.midiSlaveEnabledMenuItem});
            this.midiMenuItem.Text = "&MIDI";
            // 
            // midiInputDeviceMenuItem
            // 
            this.midiInputDeviceMenuItem.Index = 0;
            this.midiInputDeviceMenuItem.Text = "&Input Device";
            this.midiInputDeviceMenuItem.Click += new System.EventHandler(this.midiInputDeviceMenuItem_Click);
            // 
            // midiOutputDeviceMenuItem
            // 
            this.midiOutputDeviceMenuItem.Index = 1;
            this.midiOutputDeviceMenuItem.Text = "&Output Device";
            this.midiOutputDeviceMenuItem.Click += new System.EventHandler(this.midiOutputDeviceMenuItem_Click);
            // 
            // midiSeperator1MenuItem
            // 
            this.midiSeperator1MenuItem.Index = 2;
            this.midiSeperator1MenuItem.Text = "-";
            // 
            // midiMasterEnabledMenuItem
            // 
            this.midiMasterEnabledMenuItem.Index = 3;
            this.midiMasterEnabledMenuItem.Text = "&Master Enabled";
            this.midiMasterEnabledMenuItem.Click += new System.EventHandler(this.midiMasterEnabledMenuItem_Click);
            // 
            // midiSlaveEnabledMenuItem
            // 
            this.midiSlaveEnabledMenuItem.Index = 4;
            this.midiSlaveEnabledMenuItem.Text = "&Slave Enabled";
            this.midiSlaveEnabledMenuItem.Click += new System.EventHandler(this.midiSlaveEnabledMenuItem_Click);
            // 
            // helpMenuItem
            // 
            this.helpMenuItem.Index = 2;
            this.helpMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                         this.helpAboutMenuItem});
            this.helpMenuItem.Text = "&Help";
            // 
            // helpAboutMenuItem
            // 
            this.helpAboutMenuItem.Index = 0;
            this.helpAboutMenuItem.Text = "&About...";
            this.helpAboutMenuItem.Click += new System.EventHandler(this.helpAboutMenuItem_Click);
            // 
            // trackControl1
            // 
            this.trackControl1.Enabled = false;
            this.trackControl1.Location = new System.Drawing.Point(16, 24);
            this.trackControl1.Mute = false;
            this.trackControl1.Name = "trackControl1";
            this.trackControl1.Size = new System.Drawing.Size(256, 32);
            this.trackControl1.Solo = false;
            this.trackControl1.TabIndex = 0;
            this.trackControl1.TrackName = "";
            this.trackControl1.TrackNumber = 1;
            // 
            // trackControl2
            // 
            this.trackControl2.Enabled = false;
            this.trackControl2.Location = new System.Drawing.Point(16, 56);
            this.trackControl2.Mute = false;
            this.trackControl2.Name = "trackControl2";
            this.trackControl2.Size = new System.Drawing.Size(256, 32);
            this.trackControl2.Solo = false;
            this.trackControl2.TabIndex = 1;
            this.trackControl2.TrackName = "";
            this.trackControl2.TrackNumber = 2;
            // 
            // trackControl3
            // 
            this.trackControl3.Enabled = false;
            this.trackControl3.Location = new System.Drawing.Point(16, 88);
            this.trackControl3.Mute = false;
            this.trackControl3.Name = "trackControl3";
            this.trackControl3.Size = new System.Drawing.Size(256, 32);
            this.trackControl3.Solo = false;
            this.trackControl3.TabIndex = 2;
            this.trackControl3.TrackName = "";
            this.trackControl3.TrackNumber = 3;
            // 
            // trackControl4
            // 
            this.trackControl4.Enabled = false;
            this.trackControl4.Location = new System.Drawing.Point(16, 120);
            this.trackControl4.Mute = false;
            this.trackControl4.Name = "trackControl4";
            this.trackControl4.Size = new System.Drawing.Size(256, 32);
            this.trackControl4.Solo = false;
            this.trackControl4.TabIndex = 3;
            this.trackControl4.TrackName = "";
            this.trackControl4.TrackNumber = 4;
            // 
            // trackControl5
            // 
            this.trackControl5.Enabled = false;
            this.trackControl5.Location = new System.Drawing.Point(16, 248);
            this.trackControl5.Mute = false;
            this.trackControl5.Name = "trackControl5";
            this.trackControl5.Size = new System.Drawing.Size(256, 32);
            this.trackControl5.Solo = false;
            this.trackControl5.TabIndex = 7;
            this.trackControl5.TrackName = "";
            this.trackControl5.TrackNumber = 8;
            // 
            // trackControl6
            // 
            this.trackControl6.Enabled = false;
            this.trackControl6.Location = new System.Drawing.Point(16, 216);
            this.trackControl6.Mute = false;
            this.trackControl6.Name = "trackControl6";
            this.trackControl6.Size = new System.Drawing.Size(256, 32);
            this.trackControl6.Solo = false;
            this.trackControl6.TabIndex = 6;
            this.trackControl6.TrackName = "";
            this.trackControl6.TrackNumber = 7;
            // 
            // trackControl7
            // 
            this.trackControl7.Enabled = false;
            this.trackControl7.Location = new System.Drawing.Point(16, 184);
            this.trackControl7.Mute = false;
            this.trackControl7.Name = "trackControl7";
            this.trackControl7.Size = new System.Drawing.Size(256, 32);
            this.trackControl7.Solo = false;
            this.trackControl7.TabIndex = 5;
            this.trackControl7.TrackName = "";
            this.trackControl7.TrackNumber = 6;
            // 
            // trackControl8
            // 
            this.trackControl8.Enabled = false;
            this.trackControl8.Location = new System.Drawing.Point(16, 152);
            this.trackControl8.Mute = false;
            this.trackControl8.Name = "trackControl8";
            this.trackControl8.Size = new System.Drawing.Size(256, 32);
            this.trackControl8.Solo = false;
            this.trackControl8.TabIndex = 4;
            this.trackControl8.TrackName = "";
            this.trackControl8.TrackNumber = 5;
            // 
            // trackControl16
            // 
            this.trackControl16.Enabled = false;
            this.trackControl16.Location = new System.Drawing.Point(272, 248);
            this.trackControl16.Mute = false;
            this.trackControl16.Name = "trackControl16";
            this.trackControl16.Size = new System.Drawing.Size(256, 32);
            this.trackControl16.Solo = false;
            this.trackControl16.TabIndex = 15;
            this.trackControl16.TrackName = "";
            this.trackControl16.TrackNumber = 16;
            // 
            // trackControl15
            // 
            this.trackControl15.Enabled = false;
            this.trackControl15.Location = new System.Drawing.Point(272, 216);
            this.trackControl15.Mute = false;
            this.trackControl15.Name = "trackControl15";
            this.trackControl15.Size = new System.Drawing.Size(256, 32);
            this.trackControl15.Solo = false;
            this.trackControl15.TabIndex = 14;
            this.trackControl15.TrackName = "";
            this.trackControl15.TrackNumber = 15;
            // 
            // trackControl14
            // 
            this.trackControl14.Enabled = false;
            this.trackControl14.Location = new System.Drawing.Point(272, 184);
            this.trackControl14.Mute = false;
            this.trackControl14.Name = "trackControl14";
            this.trackControl14.Size = new System.Drawing.Size(256, 32);
            this.trackControl14.Solo = false;
            this.trackControl14.TabIndex = 13;
            this.trackControl14.TrackName = "";
            this.trackControl14.TrackNumber = 14;
            // 
            // trackControl13
            // 
            this.trackControl13.Enabled = false;
            this.trackControl13.Location = new System.Drawing.Point(272, 152);
            this.trackControl13.Mute = false;
            this.trackControl13.Name = "trackControl13";
            this.trackControl13.Size = new System.Drawing.Size(256, 32);
            this.trackControl13.Solo = false;
            this.trackControl13.TabIndex = 12;
            this.trackControl13.TrackName = "";
            this.trackControl13.TrackNumber = 13;
            // 
            // trackControl12
            // 
            this.trackControl12.Enabled = false;
            this.trackControl12.Location = new System.Drawing.Point(272, 120);
            this.trackControl12.Mute = false;
            this.trackControl12.Name = "trackControl12";
            this.trackControl12.Size = new System.Drawing.Size(256, 32);
            this.trackControl12.Solo = false;
            this.trackControl12.TabIndex = 11;
            this.trackControl12.TrackName = "";
            this.trackControl12.TrackNumber = 12;
            // 
            // trackControl11
            // 
            this.trackControl11.Enabled = false;
            this.trackControl11.Location = new System.Drawing.Point(272, 88);
            this.trackControl11.Mute = false;
            this.trackControl11.Name = "trackControl11";
            this.trackControl11.Size = new System.Drawing.Size(256, 32);
            this.trackControl11.Solo = false;
            this.trackControl11.TabIndex = 10;
            this.trackControl11.TrackName = "";
            this.trackControl11.TrackNumber = 11;
            // 
            // trackControl10
            // 
            this.trackControl10.Enabled = false;
            this.trackControl10.Location = new System.Drawing.Point(272, 56);
            this.trackControl10.Mute = false;
            this.trackControl10.Name = "trackControl10";
            this.trackControl10.Size = new System.Drawing.Size(256, 32);
            this.trackControl10.Solo = false;
            this.trackControl10.TabIndex = 9;
            this.trackControl10.TrackName = "";
            this.trackControl10.TrackNumber = 10;
            // 
            // trackControl9
            // 
            this.trackControl9.Enabled = false;
            this.trackControl9.Location = new System.Drawing.Point(272, 24);
            this.trackControl9.Mute = false;
            this.trackControl9.Name = "trackControl9";
            this.trackControl9.Size = new System.Drawing.Size(256, 32);
            this.trackControl9.Solo = false;
            this.trackControl9.TabIndex = 8;
            this.trackControl9.TrackName = "";
            this.trackControl9.TrackNumber = 9;
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(16, 328);
            this.startButton.Name = "startButton";
            this.startButton.TabIndex = 16;
            this.startButton.Text = "Start";
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // continueButton
            // 
            this.continueButton.Location = new System.Drawing.Point(96, 328);
            this.continueButton.Name = "continueButton";
            this.continueButton.TabIndex = 17;
            this.continueButton.Text = "Continue";
            this.continueButton.Click += new System.EventHandler(this.continueButton_Click);
            // 
            // stopButton
            // 
            this.stopButton.Location = new System.Drawing.Point(176, 328);
            this.stopButton.Name = "stopButton";
            this.stopButton.TabIndex = 18;
            this.stopButton.Text = "Stop";
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // positionHScrollBar
            // 
            this.positionHScrollBar.Location = new System.Drawing.Point(280, 336);
            this.positionHScrollBar.Name = "positionHScrollBar";
            this.positionHScrollBar.Size = new System.Drawing.Size(128, 16);
            this.positionHScrollBar.TabIndex = 19;
            this.positionHScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.positionHScrollBar_Scroll);
            // 
            // positionLabel
            // 
            this.positionLabel.Location = new System.Drawing.Point(320, 312);
            this.positionLabel.Name = "positionLabel";
            this.positionLabel.Size = new System.Drawing.Size(48, 16);
            this.positionLabel.TabIndex = 20;
            this.positionLabel.Text = "Position";
            this.positionLabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // tempoNumericUpDown
            // 
            this.tempoNumericUpDown.Location = new System.Drawing.Point(440, 328);
            this.tempoNumericUpDown.Maximum = new System.Decimal(new int[] {
                                                                               250,
                                                                               0,
                                                                               0,
                                                                               0});
            this.tempoNumericUpDown.Minimum = new System.Decimal(new int[] {
                                                                               25,
                                                                               0,
                                                                               0,
                                                                               0});
            this.tempoNumericUpDown.Name = "tempoNumericUpDown";
            this.tempoNumericUpDown.Size = new System.Drawing.Size(48, 20);
            this.tempoNumericUpDown.TabIndex = 21;
            this.tempoNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tempoNumericUpDown.Value = new System.Decimal(new int[] {
                                                                             25,
                                                                             0,
                                                                             0,
                                                                             0});
            this.tempoNumericUpDown.ValueChanged += new System.EventHandler(this.tempoNumericUpDown_ValueChanged);
            // 
            // tempoLabel
            // 
            this.tempoLabel.Location = new System.Drawing.Point(440, 312);
            this.tempoLabel.Name = "tempoLabel";
            this.tempoLabel.Size = new System.Drawing.Size(40, 16);
            this.tempoLabel.TabIndex = 22;
            this.tempoLabel.Text = "Tempo";
            this.tempoLabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // trackGroupBox
            // 
            this.trackGroupBox.Location = new System.Drawing.Point(8, 8);
            this.trackGroupBox.Name = "trackGroupBox";
            this.trackGroupBox.Size = new System.Drawing.Size(528, 280);
            this.trackGroupBox.TabIndex = 23;
            this.trackGroupBox.TabStop = false;
            this.trackGroupBox.Text = "Tracks";
            // 
            // playbackGroupBox
            // 
            this.playbackGroupBox.Location = new System.Drawing.Point(8, 296);
            this.playbackGroupBox.Name = "playbackGroupBox";
            this.playbackGroupBox.Size = new System.Drawing.Size(528, 64);
            this.playbackGroupBox.TabIndex = 24;
            this.playbackGroupBox.TabStop = false;
            this.playbackGroupBox.Text = "Playback";
            // 
            // sequencer1
            // 
            this.sequencer1.InputDeviceID = 0;
            this.sequencer1.MasterEnabled = false;
            this.sequencer1.OutputDeviceID = 0;
            this.sequencer1.Position = 0;
            this.sequencer1.SlaveEnabled = false;
            this.sequencer1.SongPositionPointer = 0;
            this.sequencer1.Tempo = 500000;
            this.sequencer1.TempoChanged += new System.EventHandler(this.TempoChangedHandler);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "mid";
            this.openFileDialog1.Filter = "MIDI Files|*.mid|All files|*.*";
            this.openFileDialog1.Title = "Open MIDI File";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(544, 369);
            this.Controls.Add(this.tempoLabel);
            this.Controls.Add(this.tempoNumericUpDown);
            this.Controls.Add(this.positionLabel);
            this.Controls.Add(this.positionHScrollBar);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.continueButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.trackControl16);
            this.Controls.Add(this.trackControl15);
            this.Controls.Add(this.trackControl14);
            this.Controls.Add(this.trackControl13);
            this.Controls.Add(this.trackControl12);
            this.Controls.Add(this.trackControl11);
            this.Controls.Add(this.trackControl10);
            this.Controls.Add(this.trackControl9);
            this.Controls.Add(this.trackControl5);
            this.Controls.Add(this.trackControl6);
            this.Controls.Add(this.trackControl7);
            this.Controls.Add(this.trackControl8);
            this.Controls.Add(this.trackControl4);
            this.Controls.Add(this.trackControl3);
            this.Controls.Add(this.trackControl2);
            this.Controls.Add(this.trackControl1);
            this.Controls.Add(this.trackGroupBox);
            this.Controls.Add(this.playbackGroupBox);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "C# MIDI Toolkit Demo";
            ((System.ComponentModel.ISupportInitialize)(this.tempoNumericUpDown)).EndInit();
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void fileOpenMenuItem_Click(object sender, System.EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            { 
                try
                {
                    sequencer1.Stop();

                    MidiFileReader reader = new MidiFileReader(openFileDialog1.FileName);

                    int i;

                    for(i = 0; i < reader.Sequence.Count && 
                        i < trackControls.Length; i++)
                    {
                        trackControls[i].Mute = false;
                        trackControls[i].Solo = false;
                        trackControls[i].Enabled = true;
                        trackControls[i].TrackName = reader.Sequence[i].Name;
                    }

                    for(; i < trackControls.Length; i++)
                    {
                        trackControls[i].Mute = false;
                        trackControls[i].Solo = false;
                        trackControls[i].TrackName = string.Empty;
                        trackControls[i].Enabled = false;
                    }

                    sequencer1.Sequence = reader.Sequence;

                    positionHScrollBar.Maximum = reader.Sequence.Length;
                }
                catch(ApplicationException ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK,
                        MessageBoxIcon.Stop);
                }
            }
        }

        private void fileExitMenuItem_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void midiInputDeviceMenuItem_Click(object sender, System.EventArgs e)
        {
            MidiInDeviceDialog dlg = new MidiInDeviceDialog(sequencer1.InputDeviceID);

            try
            {
                if(dlg.ShowDialog() == DialogResult.OK)
                {
                    sequencer1.InputDeviceID = dlg.SelectedDeviceID;
                }
            }
            finally
            {
                dlg.Dispose();
            }
        }

        private void midiOutputDeviceMenuItem_Click(object sender, System.EventArgs e)
        {
            MidiOutDeviceDialog dlg = new MidiOutDeviceDialog(sequencer1.OutputDeviceID);

            try
            {
                if(dlg.ShowDialog() == DialogResult.OK)
                {
                    sequencer1.OutputDeviceID = dlg.SelectedDeviceID;
                }
            }
            finally
            {
                dlg.Dispose();
            }        
        }

        private void midiMasterEnabledMenuItem_Click(object sender, System.EventArgs e)
        {
            midiMasterEnabledMenuItem.Checked = !midiMasterEnabledMenuItem.Checked;
            sequencer1.MasterEnabled = midiMasterEnabledMenuItem.Checked;
        }

        private void midiSlaveEnabledMenuItem_Click(object sender, System.EventArgs e)
        {
            midiSlaveEnabledMenuItem.Checked = !midiSlaveEnabledMenuItem.Checked;
            sequencer1.SlaveEnabled = midiSlaveEnabledMenuItem.Checked;
        }

        private void helpAboutMenuItem_Click(object sender, System.EventArgs e)
        {
            AboutDialog dlg = new AboutDialog();

            dlg.ShowDialog();

            dlg.Dispose();
        }

        private void OnTrackMute(object sender, EventArgs e)
        {
            TrackControl t = (TrackControl)sender;
            sequencer1.MuteTrack(t.TrackNumber - 1, t.Mute);
        }

        private void OnTrackSolo(object sender, EventArgs e)
        {
            TrackControl t = (TrackControl)sender;
            sequencer1.SoloTrack(t.TrackNumber - 1, t.Solo);
        }

        private void startButton_Click(object sender, System.EventArgs e)
        {
            sequencer1.Start();
        }

        private void continueButton_Click(object sender, System.EventArgs e)
        {
            sequencer1.Continue();
        }

        private void stopButton_Click(object sender, System.EventArgs e)
        {
            sequencer1.Stop();
        }

        private void positionHScrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            updatePosition = false;
            
            if(e.Type == ScrollEventType.EndScroll)
            {              
                SongPositionPointer spp = new SongPositionPointer(sequencer1.Sequence.Division);
                spp.PositionInTicks = e.NewValue;
                sequencer1.SongPositionPointer = spp.SongPosition;
                updatePosition = true;
            }
        }

        private void tempoNumericUpDown_ValueChanged(object sender, System.EventArgs e)
        {
            if(updateTempo)
            {
                updateTempo = false;

                sequencer1.Tempo = 60000000 / (int)tempoNumericUpDown.Value;

                updateTempo = true;
            }
        }       

        private void TempoChangedHandler(object sender, System.EventArgs e)
        {
            if(updateTempo)
                Invoke(new EventHandler(UpdateTempo));
        }

        private void UpdateTempo(object sender, System.EventArgs e)
        {
            updateTempo = false;

            tempoNumericUpDown.Value = 60000000 / sequencer1.Tempo;

            updateTempo = true;
        }      
   
        private void TickHandler(object sender, EventArgs e)
        {
            tickCounter++;

            if(tickCounter == TickInterval)
            {
                int position = sequencer1.Position;

                if(position < positionHScrollBar.Maximum && updatePosition)
                    positionHScrollBar.Value = position;

                tickCounter = 0;
            }
        }
    }
}
