using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace MidiToolkitDemo
{
    public delegate void TrackChangedEventHandler(object sender, EventArgs e);

	/// <summary>
	/// Summary description for TrackControl.
	/// </summary>
	public class TrackControl : System.Windows.Forms.UserControl
	{
        private System.Windows.Forms.CheckBox muteCheckBox;
        private System.Windows.Forms.CheckBox soloCheckBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label numberLabel;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

        public event EventHandler TrackMuted;

        public event EventHandler TrackSoloed;        

		public TrackControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.muteCheckBox = new System.Windows.Forms.CheckBox();
            this.soloCheckBox = new System.Windows.Forms.CheckBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.numberLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // muteCheckBox
            // 
            this.muteCheckBox.Location = new System.Drawing.Point(40, 8);
            this.muteCheckBox.Name = "muteCheckBox";
            this.muteCheckBox.Size = new System.Drawing.Size(48, 24);
            this.muteCheckBox.TabIndex = 0;
            this.muteCheckBox.Text = "Mute";
            this.muteCheckBox.CheckedChanged += new System.EventHandler(this.OnTrackMuted);
            // 
            // soloCheckBox
            // 
            this.soloCheckBox.Location = new System.Drawing.Point(88, 8);
            this.soloCheckBox.Name = "soloCheckBox";
            this.soloCheckBox.Size = new System.Drawing.Size(48, 24);
            this.soloCheckBox.TabIndex = 1;
            this.soloCheckBox.Text = "Solo";
            this.soloCheckBox.CheckedChanged += new System.EventHandler(this.OnTrackSoloed);
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(144, 8);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(104, 20);
            this.nameTextBox.TabIndex = 2;
            this.nameTextBox.Text = "";
            // 
            // numberLabel
            // 
            this.numberLabel.Location = new System.Drawing.Point(8, 8);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(24, 16);
            this.numberLabel.TabIndex = 3;
            this.numberLabel.Text = "1";
            this.numberLabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // TrackControl
            // 
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.soloCheckBox);
            this.Controls.Add(this.muteCheckBox);
            this.Name = "TrackControl";
            this.Size = new System.Drawing.Size(256, 32);
            this.ResumeLayout(false);

        }
		#endregion

        private void OnTrackMuted(object sender, System.EventArgs e)
        {
            if(TrackMuted != null)
                TrackMuted(this, EventArgs.Empty);        
        }

        private void OnTrackSoloed(object sender, System.EventArgs e)
        {
            if(TrackSoloed != null)
                TrackSoloed(this, EventArgs.Empty);        
        }

        public bool Mute
        {
            get
            {
                return muteCheckBox.Checked;
            }
            set
            {
                muteCheckBox.Checked = value;
            }
        }

        public bool Solo
        {
            get
            {
                return soloCheckBox.Checked;
            }
            set
            {
                soloCheckBox.Checked = value;
            }
        }

        public string TrackName
        {
            get
            {
                return nameTextBox.Text;
            }
            set
            {
                nameTextBox.Text = value;
            }
        }

        public int TrackNumber
        {
            get
            {
                return int.Parse(numberLabel.Text);
            }
            set
            {
                numberLabel.Text = value.ToString();
            }
        }
	}
}
