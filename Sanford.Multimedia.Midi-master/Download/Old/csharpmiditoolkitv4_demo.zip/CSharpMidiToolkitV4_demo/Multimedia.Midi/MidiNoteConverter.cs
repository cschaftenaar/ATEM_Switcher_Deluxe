#region License

/* Copyright (c) 2005 Leslie Sanford
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy 
 * of this software and associated documentation files (the "Software"), to 
 * deal in the Software without restriction, including without limitation the 
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or 
 * sell copies of the Software, and to permit persons to whom the Software is 
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software. 
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
 * THE SOFTWARE.
 */

#endregion

#region Contact

/*
 * Leslie Sanford
 * Email: jabberdabber@hotmail.com
 */

#endregion

using System;

namespace Multimedia.Midi
{
	/// <summary>
	/// Converts a MIDI note number to its corresponding frequency.
	/// </summary>
	public sealed class MidiNoteConverter
	{
        // Notes per octave.
        private const int NotesPerOctave = 12;

        // Offsets the note number.
        private const int NoteOffset = 9;

        // Reference frequency used for calculations.
        private const double ReferenceFrequency = 13.75;

        // Prevents instances of this class from being created - no need for
        // an instance to be created since this class only has static methods.
		private MidiNoteConverter()
		{
		}

        /// <summary>
        /// Converts note to frequency.
        /// </summary>
        /// <param name="noteNumber">
        /// The number of the note to convert.
        /// </param>
        /// <returns>
        /// The frequency of the specified note.
        /// </returns>
        public static double NoteToFrequency(int noteNumber)
        {
            double exponent = (double)(noteNumber - NoteOffset) / NotesPerOctave;

            return ReferenceFrequency * Math.Pow(2.0, exponent);
        }
	}
}
